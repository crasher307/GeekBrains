package controlWork.impl;

public class Lottery {
    public void start() {

        LotteryReel myLotteryReel = new LotteryReel();

        myLotteryReel.addLotteryLot(new LotteryLot(1,new Toy("ball"),3));
        myLotteryReel.addLotteryLot(new LotteryLot(2,new Toy("bear"),5));
        myLotteryReel.addLotteryLot(new LotteryLot(3,new Toy("doll"),7));

        myLotteryReel.spinLotteryWheel();

    }

}
