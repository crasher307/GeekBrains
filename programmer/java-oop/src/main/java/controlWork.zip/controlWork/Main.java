package controlWork;

import controlWork.impl.Lottery;

public class Main {
    private static Lottery lottery = new Lottery();
    public static void main(String[] args) {
        lottery.start();
    }
}